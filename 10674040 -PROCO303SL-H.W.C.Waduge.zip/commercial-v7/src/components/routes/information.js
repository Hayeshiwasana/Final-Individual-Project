import React from 'react';

function Information(){
    return (
        <>
        </>
    );
}

export default Information;