import React from 'react';
import DocGen from '../../plugins/docgen/docgen';
import './form-style.css';



function TestForm(){
    return (
        <div className="doc-area">
            <DocGen />
        </div>
    )
} 

export default TestForm;
