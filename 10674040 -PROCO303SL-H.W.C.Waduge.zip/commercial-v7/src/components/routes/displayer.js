import React from 'react';

function Displayer(){
    return (
        <>
        </>
    );
}

export default Displayer;