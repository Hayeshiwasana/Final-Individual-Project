import React from 'react';
import { TimePickerComponent } from '@syncfusion/ej2-react-calendars';
import './sync.css';

function TimePicker(){
    return (<TimePickerComponent/>);
}

export default TimePicker; 