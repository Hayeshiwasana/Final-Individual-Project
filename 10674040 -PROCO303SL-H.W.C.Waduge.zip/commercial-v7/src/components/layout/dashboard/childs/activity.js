import React from 'react';
import '../dashboard.css';

function Activity(){
    return (
        <>
            
        </>
    )
}

export default Activity;