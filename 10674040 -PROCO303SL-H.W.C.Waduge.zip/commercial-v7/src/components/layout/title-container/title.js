import React from 'react';
import { useHistory } from 'react-router-dom';
import './title.css';

function Title(props) {

    const history = useHistory();
    const title = props.model?props.model.title:"No Title";
    return (
        <>
            <div className="container-title">
                <button className="btn ct-btn" onClick={()=>history.goBack()}>Back</button> <span className="ct-braker">|</span>    <span>{title}</span>
            </div>

        </>
        
    );
}

export default Title;
