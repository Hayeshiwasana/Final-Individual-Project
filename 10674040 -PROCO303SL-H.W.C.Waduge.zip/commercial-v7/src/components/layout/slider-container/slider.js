import React from 'react';
// import { Link } from 'react-router-dom';
import { slides_list, special_card_list } from '../../../values/content';
import { CardSpecial } from '../../plugins/cards/card-smart';
import './slider.css';

function Slider(){
    // var i = 1;
    return (
        <>
            <div className="ct-slider-container">

                <div className="ct-slider-header ct-flex">
                    <div className="slider-img" >
                        {/* <img src={'assets/resources/bannerLI.jpg'} /> */}
                    </div>
                    <div className="slider-content">

                        <div className="text-right">
                            <h1 className="ct-font-sp ct-font-secondary">{slides_list[0].title}</h1>
                            <h4 className="ct-font-secondary">{slides_list[0].subtitle}</h4>
                            <p className="ct-font-secondary">Treatment for mental illnesses usually consists of therapy, medication, or a combination of the two. Treatment can be given in person or through a phone or computer (telemental health). It can sometimes be difficult to know where to start when looking for mental health care, but there are many ways to find a provider who will meet your needs. Your primary care practitioner can be an important resource, providing initial mental health screenings and referrals to mental health specialists. If you have an appointment with your primary care provider, consider bringing up your mental health concerns and asking for help.</p>
                            <p className="ct-font-secondary"> Some federal agencies offer resources for identifying health care providers and help in finding low-cost health services. These include:</p>
                        </div>
                        
                    </div> 
                </div>

                <div className="ct-slider-footer ct-flex">
                    
                    {
                        special_card_list.map(element => <CardSpecial model={element}/>)
                    }

                </div>
                
            </div>
        </>
    );
}

export default Slider;