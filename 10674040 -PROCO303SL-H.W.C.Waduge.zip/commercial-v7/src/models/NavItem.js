

class NavItem {
    constructor(item, url, content, author, resource){
        this.item = item;
        this.url = url;
        this.content = content;
        this.author = author;
        this.resource = resource;
    }
}

export default NavItem;