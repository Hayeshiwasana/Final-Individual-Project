const env = require('dotenv').config();

module.exports = {
    firebaseConfig : {
        apiKey: "AIzaSyC0kXUk-07R5YjADaw1aHLdeDa9x7KtT_U",
        authDomain: "councilor-app.firebaseapp.com",
        projectId: "councilor-app",
        storageBucket: "councilor-app.appspot.com",
        messagingSenderId: "867023725003",
        appId: "1:867023725003:web:c832d257e85c030672564e"
    }
}